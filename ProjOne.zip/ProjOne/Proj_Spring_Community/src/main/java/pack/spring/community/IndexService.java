package pack.spring.community;

public interface IndexService {
	String index( );
}
