package pack.spring.community;

import org.springframework.stereotype.Service;

@Service
public class IndexServiceImp implements IndexService{

	@Override
	public String index() {
		return null;
	}
	
}
